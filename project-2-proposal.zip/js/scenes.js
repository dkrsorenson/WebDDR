import { createArrowSprite, createRectSprite, createBackgroundSprite } from './sprites.js'
import { getRandomColor } from './utilities.js'
import { keysPressed } from './input.js'
export { currentScene, drawStart, startInit, gameInit, drawGame }

let currentScene = "game";
let spriteList = [];
let backgroundSprite;
let timer;

function startInit(){
    spriteList = [];
    backgroundSprite = createBackgroundSprite();
    timer = 0;

    spriteList.push(createArrowSprite(50, 50));
}

function drawStart(ctx, screenWidth, screenHeight){
    // draw background
    drawBackgroundColors(ctx, screenWidth, screenHeight);
    backgroundSprite.draw(ctx);
    //drawBackgroundColors(ctx, screenWidth, screenHeight);
    
    for (let s of spriteList){
        s.draw(ctx);
    }
    
    timer++;
}

function drawBackgroundColors(ctx, screenWidth, screenHeight){
    if (timer % 45 == 0)
        UpdateBackgroundColors(ctx);

    ctx.fillRect(0, 0, screenWidth, screenHeight);
}

function UpdateBackgroundColors(ctx){
    ctx.fillStyle = getRandomColor();
}

function gameInit(ctx){
    spriteList = [];

    // goal Arrow locations
    spriteList.push(createArrowSprite(60, 100, {x: 1, y: 0}, "white", 75, 100));
    spriteList.push(createArrowSprite(60, 250, {x: 1, y: 0}, "white", 75, 100, (90 * Math.PI / 180)));
    ctx.restore();
    spriteList.push(createArrowSprite(60, 400, {x: 1, y: 0}, "white", 75, 100, (180 * Math.PI / 180)));
    spriteList.push(createArrowSprite(60, 550, {x: 1, y: 0}, "white", 75, 100, (270 * Math.PI / 180)));
}

function drawGame(ctx, screenWidth, screenHeight){
    for (let s of spriteList){
        console.dir(s.angle);
        if (s.angle == 0) {
            s.checkColor(keysPressed["38"]);
            s.draw(ctx);
        }

        if (s.angle == 90 * Math.PI / 180) {
            s.checkColor(keysPressed["39"]);
            s.draw(ctx);
        }

        if (s.angle == 180 * Math.PI / 180) {
            s.checkColor(keysPressed["40"]);
            s.draw(ctx);
        }

        if (s.angle == 270 * Math.PI / 180) {
            s.checkColor(keysPressed["37"]);
            s.draw(ctx);
        }
    }
}