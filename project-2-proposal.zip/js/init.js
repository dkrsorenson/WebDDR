import {init} from './main.js';
// 1) this script a good place to load fonts, images, sounds and other resources
// 2) start up app
window.onload = init();